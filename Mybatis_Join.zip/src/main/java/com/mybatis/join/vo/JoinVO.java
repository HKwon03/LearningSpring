package com.mybatis.join.vo;

import lombok.Data;

@Data
public class JoinVO {
	
	private EmployeeVO empJ;
	private DepartmentVO deptJ;
	
}
