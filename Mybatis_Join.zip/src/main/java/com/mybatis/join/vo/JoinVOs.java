package com.mybatis.join.vo;

import lombok.Data;

@Data
public class JoinVOs {
	
	private EmployeeVOs empJs;
	private DepartmentVOs deptJs;
	
}
